package andyly_CSCI201L_Assignment1;

public class Movies {
	private String title, director, genre, description;
	private String[] writers, actors;
	private int year, rating;
	
	public Movies(String _title, String _director, String _genre, 
			String _description, String[] _writers, String[] _actors,
			int _year, int _rating) 
	{
		title = _title;
		director = _director;
		genre = _genre;
		description = _description;
		for(int i=0; i<_writers.length; i++) {
			writers[i] = _writers[i];
		}
		for(int i=0; i<_actors.length; i++) {
			actors[i] = _actors[i];
		}
		year = _year;
		rating = _rating;
	}
	
	
}
