package andyly_CSCI201L_Assignment1;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

public class DomParser {
	
	private static final HashSet<String> NULL = null;

	public static void main(String[] args) {
		//create document parser
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		try {
			DocumentBuilder builder = factory.newDocumentBuilder();
			//use command line arugment to read in file
			Document doc = builder.parse(args[0]);
			
			//create nodelists
			NodeList genresTag = doc.getElementsByTagName("genres");
			NodeList actionsTag = doc.getElementsByTagName("actions");
			NodeList moviesTag = doc.getElementsByTagName("movies");
			NodeList usersTag = doc.getElementsByTagName("users");
			
			//create set of different types of genres
			Node g = genresTag.item(0);
			NodeList genreList = g.getChildNodes();
			HashSet<String> genres  = new HashSet<String>();
			for(int i=0; i<genreList.getLength(); i++) {
				Node gL = genreList.item(i);
				if(gL.getNodeType() == Node.ELEMENT_NODE) {
					genres.add(gL.getTextContent());
				}
			}
			
			//create set of different types of actions
			Node a = actionsTag.item(0);
			NodeList actionList = a.getChildNodes();
			HashSet<String> actions  = new HashSet<String>();
			for(int i=0; i<actionList.getLength(); i++) {
				Node aL = actionList.item(i);
				if(aL.getNodeType() == Node.ELEMENT_NODE) {
					actions.add(aL.getTextContent());
				}
			}
			
			//create a instance of movie object for each movie and 
			//sets for searching
			Node m = moviesTag.item(0);
			NodeList movieList = m.getChildNodes();
			HashSet<String> movieTitles = new HashSet<String>();
			HashMap<String, HashSet<String>> movieActors = new HashMap<String, HashSet<String>>();
			HashMap<String, HashSet<String>> movieGenre = new HashMap<String, HashSet<String>>();
			for(int i=0; i < movieList.getLength(); i++) {
				Node movie = movieList.item(i);
				NodeList movieInfo = movie.getChildNodes();
				String title, director, genre, description;
//				String[] writers, actors;
//				int year, rating;
				title = "";
				for(int j=0; j < movieInfo.getLength(); j++) {
					Node mI = movieInfo.item(j);
					if(mI.getNodeType() == Node.ELEMENT_NODE) {
						if(mI.getNodeName() == "title") {
							title = mI.getTextContent();
							movieTitles.add(mI.getTextContent());
						}
						else if(mI.getNodeName() == "genre") {
							if(movieGenre.get(mI.getTextContent()) != NULL) {
								movieGenre.get(mI.getTextContent()).add(title);
							}
							else {
								HashSet<String> genreSet = new HashSet<String>();
								movieGenre.put()
							}
						}
						else if(mI.getNodeName() == "actors") {
							
						}
					}
				}
				
				
				

				
			}
		
			
			
			
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
 