package andyly_CSCI201L_Assignment1;

public class Menu {

	public static void main(String[] args) {
		

	}

}
